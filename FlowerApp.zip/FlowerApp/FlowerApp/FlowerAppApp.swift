//
//  FlowerAppApp.swift
//  FlowerApp
//
//  Created by HARSH TRIVEDI on 07/07/24.
//

import SwiftUI

@main
struct FlowerAppApp: App {
    var body: some Scene {
        WindowGroup {
           FlowerListView()
        }
    }
}
